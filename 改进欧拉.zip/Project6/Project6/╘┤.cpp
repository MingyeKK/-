#include<iostream>
using namespace std;

double f(double x, double y) {  //΢�ַ����Ҷ˺���
	return (y - (2*x/y) );
}

void Euler(double x0, double y0, double h, int N) {  //�Ľ���ŷ����ʽ
	double yp, yc, x = x0, y = y0;

	for (int i = 1; i <= N; i++) {
		yp = y + h * f(x, y);
		x = x0 + i * h;
		yc = y + h * f(x, yp);
		y = (yp + yc) / 2.0;
		//printf("x%d = %f     y%d = %f\n", i, x, i, y);
		cout << "x" << i << "=" << x << "    " << "y" << i << "=" << y<<endl;
	}
}

int main() {
	//double x0 = 1, xn = 1.5, y0 = 0.5, n = 5;
	double x0, y0, N, h;
	cout << "x0:";
	cin >> x0;
	cout << "y0:";
	cin >> y0;
	cout << "h:";
	cin >> h;
	cout << "N:";
	cin >> N;
	//printf("x0 = %f     y0 = %f\n", x0, y0);
	cout << "x0=" << x0 << "     " << "y0" << y0 << endl;
	Euler(x0, y0, h, N);

	return 0;
}
