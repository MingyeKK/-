#include<iostream>
using namespace std;

double f(double x, double y) {  //΢�ַ����Ҷ˺���
	return (y - (2 * x / y));
}

void Runge(double x0, double y0, double h, int N) {  //�Ľ���ŷ����ʽ
	double K1, K2, K3, K4, x1, y1, x = x0, y = y0;

	for (int i = 1; i <= N; i++) {
		//yp = y + h * f(x, y);
		//x = x0 + i * h;
		//yc = y + h * f(x, yp);
		//y = (yp + yc) / 2.0;
		//printf("x%d = %f     y%d = %f\n", i, x, i, y);
		x1 = x0 + h;
		K1 = f(x0, y0);
		K2 = f(x0 + (h / 2), y0 + (h / 2)*K1);
		K3 = f(x0 + (h / 2), y0 + (h / 2)*K2);
		K4 = f(x1, y0 + h*K3);
		y1 = y0 + h*(K1 + 2*K2 + 2*K3 + K4) / 6;
		cout << "x" << i << "=" << x1 << "    " << "y" << i << "=" << y1 << endl;
		x0 = x1;
		y0 = y1;
	}
}

int main() {
	//double x0 = 1, xn = 1.5, y0 = 0.5, n = 5;
	double x0, y0, N, h;
	cout << "x0:";
	cin >> x0;
	cout << "y0:";
	cin >> y0;
	cout << "h:";
	cin >> h;
	cout << "N:";
	cin >> N;
	//printf("x0 = %f     y0 = %f\n", x0, y0);
	cout << "x0=" << x0 << "     " << "y0" << y0 << endl;
	Runge(x0, y0, h, N);

	return 0;
}
