#include<iostream>
using namespace std;

const int N = 100;


void fx(float Xi[], float Yi[], int n, float x) {
	float Ln = 0;
	float pk[N];
	float temp1, temp2;
	for (int i = 0; i < n; i++) {
		temp1 = 1;
		temp2 = 1;
		for (int j = 0; j < n; j++) {
			if (i == j) {
				continue;
			}
			temp1 = temp1 * (x - Xi[j]);
			temp2 = temp2 * (Xi[i] - Xi[j]);
			
		}
		pk[i] = temp1 / temp2;
	}
	for (int i = 0; i < n; i++) {
		Ln = Ln + Yi[i] * pk[i];
	}

	cout << Ln << endl;
}

int main() {
	float Xi[100];
	float Yi[100];
	int num;
	cout << "������";
	cin >> num;
	cout << "Xi[i]��Yi[i]:";
	for (int i = 0; i < num; i++) {
		cin >> Xi[i] >> Yi[i];
	}
	float x;
	cout << "Ҫ�����ֵ��X��";
	cin >> x;
	fx(Xi,Yi,num,x);
	return 0;
}

