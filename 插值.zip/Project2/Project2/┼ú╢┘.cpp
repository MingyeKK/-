#include<iostream> 
#define maxn 100
using namespace std;

double Xi[maxn];
double table[maxn][maxn] = { 0 };
int n;

double Newton(double & y1, double & y2, double & x1, double & x2);

int main()
{
	double result, x, temp;
	cout << "������Ҫ��ֵ����Ŀ : ";
	cin >> n;
	cout << "Xi : ";
	for (int i = 0; i < n; i++)
		cin >> Xi[i];
	cout << "Yi : ";
	for (int i = 0; i < n; i++)
		cin >> table[i][0];
	for (int i = 1; i < n; i++)
		for (int j = i; j < n; j++)
		{
			table[j][i] = Newton(table[j][i - 1], table[j - 1][i - 1], Xi[j], Xi[j - i]);
		}
	cout << "������Ҫ��ֵ��x : " << endl;
	cin >> x;
	result = table[0][0];
	for (int i = 1; i < n; i++)
	{
		temp = table[i][i];
		for (int j = i - 1; j >= 0; j--)
			temp *= (x - Xi[j]);
		result += temp;
	}
	cout << "y : " << result << endl;
	return 0;
}


double Newton(double & y1, double & y2, double & x1, double & x2)
{
	return (y2 - y1) / (x2 - x1);
}
