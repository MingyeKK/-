#include<iostream>
using namespace std;
#define maxn 100

double Xi[maxn];
double Yi[maxn];
int n;
double avex, avey;

int main() {
	cout << "�����ĸ���:";
	cin >> n;
	cout << "Xi:";
	for (int i = 0; i < n; i++) {
		cin >> Xi[i];
		avex += Xi[i];
	}
	cout << "Yi:";
	for (int i = 0; i < n; i++) {
		cin >> Yi[i];
		avey += Yi[i];
	}

	avex /= n;
	avey /= n;
	//cout << avex << " " << avey;

	double temp1 = 0;
	double temp2 = 0;
	for (int i = 0; i < n; i++) {
		temp1 += (Xi[i] - avex)*(Yi[i] - avey);
		temp2 += (Xi[i] - avex)*(Xi[i] - avex);
	}
	double b = 0;
	double a = 0;
	b = temp1 / temp2;
	a = avey - b * avex;

	cout << "���ֱ��Ϊ��" << "y=" << b << "x" << a;
}
